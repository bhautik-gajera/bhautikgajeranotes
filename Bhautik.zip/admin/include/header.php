<?php
ob_start();
session_start();
include('connect.php');
?>